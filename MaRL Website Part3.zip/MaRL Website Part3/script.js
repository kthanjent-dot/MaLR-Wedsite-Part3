document.addEventListener('DOMContentLoaded', () => {
  const menuToggle = document.querySelector('.menu-toggle');
  const nav = document.querySelector('nav');
  const navLinks = document.querySelectorAll('nav a');
  const newsletterTrigger = document.querySelector('.newsletter-trigger');
  const newsletterModal = document.querySelector('.newsletter-modal');
  const newsletterClose = document.querySelector('.newsletter-close');

  const updateMenuState = (isOpen) => {
    if (!nav || !menuToggle) return;
    nav.classList.toggle('open', isOpen);
    menuToggle.setAttribute('aria-expanded', String(isOpen));
    menuToggle.textContent = isOpen ? '✕' : '☰';
  };

  if (menuToggle && nav) {
    menuToggle.addEventListener('click', () => {
      const isOpen = !nav.classList.contains('open');
      updateMenuState(isOpen);
    });

    navLinks.forEach((link) => {
      link.addEventListener('click', () => {
        updateMenuState(false);
      });
    });

    window.addEventListener('resize', () => {
      if (window.innerWidth > 699) {
        updateMenuState(false);
      }
    });
  }

  const openNewsletterModal = () => {
    if (newsletterModal) {
      newsletterModal.hidden = false;
      const emailInput = newsletterModal.querySelector('input[type="email"]');
      if (emailInput) {
        emailInput.focus();
      }
    }
  };

  const closeNewsletterModal = () => {
    if (newsletterModal) {
      newsletterModal.hidden = true;
    }
  };

  newsletterTrigger?.addEventListener('click', openNewsletterModal);
  newsletterClose?.addEventListener('click', closeNewsletterModal);

  newsletterModal?.addEventListener('click', (event) => {
    if (event.target === newsletterModal) {
      closeNewsletterModal();
    }
  });

  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && newsletterModal && !newsletterModal.hidden) {
      closeNewsletterModal();
    }
  });

  const currentPage = window.location.pathname.split('/').pop().split('?')[0].split('#')[0];
  navLinks.forEach((link) => {
    const linkHref = link.getAttribute('href') || '';
    const normalizedLink = linkHref.split('?')[0].split('#')[0].split('/').pop();

    if (normalizedLink === currentPage || link.href === window.location.href) {
      link.classList.add('active');
    } else {
      link.classList.remove('active');
    }
  });

  const slides = document.querySelectorAll('.slide');
  const dots = document.querySelectorAll('.slider-dot');
  const prevBtn = document.querySelector('.slider-btn.prev');
  const nextBtn = document.querySelector('.slider-btn.next');
  let currentSlide = 0;

  function showSlide(index) {
    slides.forEach((slide, slideIndex) => {
      slide.classList.toggle('active', slideIndex === index);
    });
    dots.forEach((dot, dotIndex) => {
      dot.classList.toggle('active', dotIndex === index);
    });
  }

  function moveSlide(step) {
    currentSlide = (currentSlide + step + slides.length) % slides.length;
    showSlide(currentSlide);
  }

  if (slides.length > 0) {
    prevBtn?.addEventListener('click', () => moveSlide(-1));
    nextBtn?.addEventListener('click', () => moveSlide(1));

    dots.forEach((dot, index) => {
      dot.addEventListener('click', () => {
        currentSlide = index;
        showSlide(currentSlide);
      });
    });

    setInterval(() => moveSlide(1), 5000);
  }

  const year = document.getElementById('year');
  if (year) {
    year.textContent = new Date().getFullYear();
  }

  document.querySelectorAll('form').forEach((form) => {
    const status = form.querySelector('.form-status');
    const isNewsletterForm = form.classList.contains('newsletter-form-modal') || form.closest('.newsletter-modal') !== null;

    form.addEventListener('submit', (event) => {
      event.preventDefault();

      const requiredFields = form.querySelectorAll('[required]');
      let allFilled = true;

      requiredFields.forEach((field) => {
        if (!field.value.trim()) {
          allFilled = false;
        }
      });

      if (!allFilled) {
        if (status) {
          status.textContent = 'Please complete all required fields.';
          status.className = 'form-status error';
        }
        return;
      }

      if (status) {
        status.textContent = 'Thank you! Your message has been sent successfully.';
        status.className = 'form-status success';
      }

      form.reset();

      if (isNewsletterForm) {
        setTimeout(() => {
          closeNewsletterModal();
        }, 700);
      }
    });
  });
});
